// src/components/Contact.js

import React from 'react';

const Contact = () => {
  return (
    <div>
      <h2>İletişim</h2>
      <p>Bize ulaşın!</p>
    </div>
  );
}

export default Contact;
